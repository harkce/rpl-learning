<?php
$SERVER = "localhost";
$DBUSER = "root";
$DBPASS = "";
$DBNAME = "rpl";